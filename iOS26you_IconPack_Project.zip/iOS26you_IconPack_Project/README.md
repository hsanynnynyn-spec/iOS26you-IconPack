# iOS 26 You Icon Pack — Android Studio project

Extracted from the supplied Xiaomi theme `icons` archive.

## Included
- 263 static app icon PNGs copied into `drawable-nodpi`.
- `res/xml/appfilter.xml` with package-level component mappings.
- Original `fancy_icons/`, `nightmode/`, and `transform_config.xml` files preserved under `original_theme_data/`.

## Important compatibility note
This is a **source project**, not an installable APK. This runtime does not have Android build-tools/Gradle installed, so no APK has been compiled or signed here.

The theme's live clock/calendar animations use Xiaomi Theme Engine XML and are **not converted into Android launcher animations**. Their original assets/manifests are preserved separately. A standard Android icon pack cannot reproduce those Xiaomi live-icon behaviours by itself.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Launcher mapping caveat
The `appfilter.xml` uses package-level placeholder components (`ComponentInfo{package/package}`). Some launchers require exact launch-activity class names for each app. If HyperOS Launcher Mod does not apply an icon, that app will need its exact activity component added to `appfilter.xml`.

The pack's availability in the HyperOS Launcher Mod picker is not guaranteed until tested on the phone. Install only after building and signing the APK.
