package com.ios26you.iconpack;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.view.Gravity;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView v = new TextView(this);
        v.setText("iOS 26 You Icon Pack\\n\\nIcon assets are included.\\nUse a compatible launcher icon-pack picker.");
        v.setGravity(Gravity.CENTER);
        v.setTextSize(18);
        setContentView(v);
    }
}
